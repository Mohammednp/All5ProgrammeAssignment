package ptterns;

public class P2 {

	public static void main(String[] args) {
		int n=3;
		for(int i=0; i<=n; i++) {
			for(int j=0; j<=n; j++) {
				if(i==0) {
					System.out.print("1 ");
				}else if(i==1) {
					System.out.print("2 ");
				}else if(i==2) {
					System.out.print("3 ");
				}else {
					System.out.print("4 ");
				}
			}
					System.out.println( );
		}
	}

}
